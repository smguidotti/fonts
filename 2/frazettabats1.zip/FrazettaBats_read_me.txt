FrazettaBats by Frank Frazetta. Fonted by bobistheowl for Metaphase Brothel Graphix, 2008. All rights reserved. This font is freeware. Have fun with it. If you like it, let me know at: bobistheowl@hotmail.com This font was made with MS Paint and ScanFont 3.13.
For more fonts from Metaphase Brothel Graphix, please visit our homepage on Luc Devroye's site: 

http://cg.scs.carleton.ca/~luc/bobistheowl.html

FrazettaBats1 is the first of a series of fonts commemorating the 80th birthday of the World's foremost fantasy and science fiction Artist, Frank Frazetta. 

Frank Frazetta was born on February 9, 1928 is Brooklyn, New York. His art talent was apparent at a young age, and his parents enrolled him in the Brooklyn Academy of Fine Arts at age 8. At age 16, Frazetta began drawing comic books professionally, a career which lasted through the mid 1950's, most memorably with EC Comics, mainly in collaboration with Al Williamson, Roy Krenkel, and Angelo Torres. Through the late 1950's and early 1960's, Frazetta assisted Al Capp on the L'il Abner newspaper comic strip, and also worked with Harvey Kurtzman and Bill Elder on Little Annie Fanny for Playboy, often uncredited.

In the mid 1960's, Lancer Books began to reprint the Conan series by Robert E. Howard, and Frazetta reached a whole new audience, as a paperbook book cover artist. During this time, he also drew many covers and frontpieces for Ace Books' editions of the science fiction books by Edgar Rice Burroughs, and if it had ever been in doubt, his reputation as a master of heroic fantasy art was assured. 

Frank currently lives in the Pocono mountains of Pennsyvania, with his wife, Ellie, who has been the subject of many of his completed works and studies. Together, they maintain a small museum on the site of their estate. 

Other fonts from Metaphase Brothel Graphix include:

Alice in Wonderland
AmyBats1-5
Apoux
Gypsy Tarot series
HaydenPanettiereBats
KleinKarpets
Through the Looking Glass series

and many more. 

~bobistheowl
  

