﻿The font file in this archive was created using Fontstruct the free, online
font-building tool.
This font was created by Myname5749 *.
This font has a homepage where this archive and other versions may be found:
https://fontstruct.com/fontstructions/show/1737069

*NOTE: “Dragon Warrior III” was originally cloned (copied) from the
FontStruction “Dragon Warrior IV”
(https://fontstruct.com/fontstructions/show/1709714) by Myname5749 , which is
licensed under a FontStruct Non-Commercial License license
(https://fontstruct.com/fontstructions/license/1709714).

Try Fontstruct at https://fontstruct.com
It’s easy and it’s fun.

Fontstruct is copyright ©2020 Rob Meek

LEGAL NOTICE:
In using this font you must comply with the licensing terms described in the
file “license.txt” included with this archive.
If you redistribute the font file in this archive, it must be accompanied by all
the other files from this archive, including this one.
